package model

case class Student(var id: Int, var name: String, var age: Int)
